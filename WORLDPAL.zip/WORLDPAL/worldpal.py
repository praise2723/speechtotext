# the modules
from tkinter import *
import pyttsx3
from tkinter import ttk
from PIL import ImageTk, Image
import speech_recognition as sr
import datetime
import webbrowser
import os
import smtplib as smtp
import pyautogui
#layout
praise=Tk()
praise.geometry("603x600")
praise.resizable(False,False)
praise.title("WORLDPAL")

spath = "bo2.jpg"
simg = ImageTk.PhotoImage(Image.open(spath))
my = Label(praise, image=simg)
my.image = simg
my.place(x=0, y=0)

Label(praise, text="Made by -",bg="white",fg="blue", font='thinoo').place(x=390, y=10)
Label(praise, text="Adeyemi Praise O.",bg="white",fg="blue", font='thinoo ').place(x=390, y=30)
Label(praise, text="praiseadeyemi55@gmail.com",fg="blue", bg="white",font="thinoo",).place(x=390, y=50)

#performance
def worldpal():
        
        jarv = pyttsx3.init('sapi5')
        voices = jarv.getProperty('voices')
        jarv.setProperty('voice', voices[0].id)
        
        
        def speak(audio):
            jarv.say(audio)
            jarv.runAndWait()

        def greet():
            time = int(datetime.datetime.now().hour)
            if time >= 0 and time < 12:
                speak("Good Morning  what can I do for you ")

            elif time>= 12 and time < 16:
                speak(" Good Afternoon  what can I do for you ")   

            elif time>=16 and time < 20:
                speak("  Good Evening what can I do for you  ")  

            elif time>=20 and time < 24:
                speak(" Good Night what can I do for you  ")          

        def listen():
            rec = sr.Recognizer()
            with sr.Microphone() as source:
                rec.adjust_for_ambient_noise(source, duration=1)
                speak("am Listening...")
                rec.pause_threshold = 1
                audio = rec.listen(source)
                speak(" processing...")    
                command = rec.recognize_google(audio, language='english') 
                speak(command)
            return command
        if__name__ = "__main__"  
        greet()
        
        while True :
            listen()
            task = listen().lower()
            if "open youtube" in task :
                webbrowser.open("https://www.youtube.com") 
            elif "open google"  in task :
                webbrowser.open("https://www.google.com/")
            elif "open facebook" in task :
                webbrowser.open("https://www.facebook.com/")
            elif "open instagram" in task :
                webbrowser.open("https://www.instagram.com/")
            elif "open amazon" in task:
                webbrowser.open("https://www.amazon.com/")
            elif "open netflix" in task:
                webbrowser.open("https://www.netflix.com/")
            elif "open movies" in task:
                webbrowser.open("https://www.nkiri.com/")
            elif "open whatsapp" in task:
                webbrowser.open("https://www.whatsapp.com/")               
            elif " time"  in task :
                Dtime = datetime.datetime.now().strftime("%H:%M:%H")
                speak(f"the time is {Dtime}")
            elif "open mail" in task :
                webbrowser.open("https://mail.google.com/mail/")
            elif "open music" in task :
                webbrowser.open("https://www.naijaloaded.com")
            elif "rest" in task : 
                speak("Thank you for your free time , have a good day ")
                exit()
            elif "give your intro" in task :
                speak(" I am assistant created by Master praise. which uses speech recognition designed to help in your various needs,which will be listed by my master on the page which you are ,when you click functions")                
            elif "open notepad" in task :
                notePad = "C:\\Windows\\Notepad.exe"
                os.startfile(notePad)               
            else :
                speak("  sorry i could not recognize that please try again ") 
btn=Button(praise,text="launch",fg="white",bg="blue",font="thinoo",command=worldpal)
btn.place(x=200,y=550)
btn=Button(praise,text="x",fg="white",bg="red",font="thinoo",command=exit)
btn.place(x=290,y=550)

def functions():
    Frame(praise,bg="white",height=203,width=280).place(x=150, y=150)
    Label(praise, text="FUNCTIONS",fg="blue", bg="white",font="thinoo",).place(x=240, y=160)
    Label(praise, text="Open youtube",fg="blue", bg="white",font="thinoo",).place(x=160, y=180)
    Label(praise, text="Open google",fg="blue", bg="white",font="thinoo",).place(x=160, y=200)
    Label(praise, text="GIVE YOUR INTRO",fg="blue", bg="white",font="thinoo",).place(x=160, y=220)
    Label(praise, text="Open facebook",fg="blue", bg="white",font="thinoo",).place(x=160, y=240)
    Label(praise, text="Open instagram",fg="blue", bg="white",font="thinoo",).place(x=160, y=260)
    Label(praise, text="Open amazon",fg="blue", bg="white",font="thinoo",).place(x=160, y=280)
    Label(praise, text="Open netflix",fg="blue", bg="white",font="thinoo",).place(x=160, y=300)
    Label(praise, text="Open movies",fg="blue", bg="white",font="thinoo",).place(x=160, y=320)
    Label(praise, text="Open whatsapp",fg="blue", bg="white",font="thinoo",).place(x=300, y=180)
    Label(praise, text=" Time",fg="blue", bg="white",font="thinoo",).place(x=300, y=200)
    Label(praise, text="Open mails",fg="blue", bg="white",font="thinoo",).place(x=300, y=220)
    Label(praise, text="Open music",fg="blue", bg="white",font="thinoo",).place(x=300, y=240)
    Label(praise, text="Open notepad",fg="blue", bg="white",font="thinoo",).place(x=300, y=260)
    Label(praise, text="REST",fg="blue", bg="white",font="thinoo",).place(x=300, y=280)
    
    
    def mode():
        Frame(praise,height=60,width=283,bg="white").place(x=150,y=300)
        
        def listen():
            jarv = pyttsx3.init('sapi5')
            voices = jarv.getProperty('voices')
            jarv.setProperty('voice', voices[0].id)
            def speak(audio):
                jarv.say(audio)
                jarv.runAndWait()
            
            def openword():
                pyautogui.press('win', interval=0.2)
                pyautogui.typewrite('word', interval=0.1)
                pyautogui.press('enter', interval=0.2)
            def takeCommand():
                r = sr.Recognizer()
                with sr.Microphone() as source:
                    speak("Listening...")
                    r.pause_threshold = 1
                    audio = r.listen(source)
                try:
                    speak("Recognizing...")
                    query = r.recognize_google(audio, language='en-in')
                    pyautogui.press('space',interval=0.2)
                    pyautogui.typewrite(query)
                    if "new line" in query:
                        pyautogui.press('enter')
                    elif "termination" in query:
                        exit()
                except Exception as e:
                    print("Say that again please...")
                    return "None"
                return query
            if __name__ == "__main__":
                    openword()
                    while True:
                        takeCommand()
        
        def lis():
            jarv = pyttsx3.init('sapi5')
            voices = jarv.getProperty('voices')
            jarv.setProperty('voice', voices[0].id)
            def speak(audio):
                jarv.say(audio)
                jarv.runAndWait()
            

            def take():
                r = sr.Recognizer()
                with sr.Microphone() as source:
                    speak("Listening...")
                    r.pause_threshold = 1
                    audio = r.listen(source)
                try:
                    speak("Recognizing...")
                    query = r.recognize_google(audio, language='en-in') 
                    pyautogui.press('space',interval=0.2)
                    pyautogui.typewrite(query)
                    if "new line" in query:
                        pyautogui.press('enter')
                    elif "terminate" in query:
                        exit()
                except Exception as e:
                    speak("Say that again please...")
                    return "None"
                return query
            if __name__ == "__main__":
                    take() 
                    while True:
                        take()   
                                  
        Button(praise, text='start word ', font='thinoo', fg='blue', command=listen).place(x=300, y=320) 
        Button(praise, text='others', font='thinoo', fg='blue', command=lis).place(x=220, y=320)
        Button(praise,text="X",bg="red",fg="white",width=2,height=1 ,command=exit).place(x=408,y=320)
    Button(praise, text='Speech to text ', font='thinoo', fg='red', command=mode).place(x=300, y=320)
    
btn2=Button(praise,text="functions",bg="blue",fg="white",font="thinoo",command=functions)
btn2.place(x=340,y=550)

praise.mainloop()